Week 6 entries:
Parts 4 - 7 are all reproducing graphs for 2020 data
Split between many notebooks due to time crunch
week 8 onwards:
Moved away from code diaries to cleaning the final notebooks